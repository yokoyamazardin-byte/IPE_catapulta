#|
$JSON
{"authURL":["ai2a.appinventor.mit.edu"],"YaVersion":"233","Source":"Form","Properties":{"$Name":"Screen1","$Type":"Form","$Version":"31","ActionBar":"True","AppName":"Aplicativo_Catapulta","Title":"Screen1","Uuid":"0","$Components":[{"$Name":"ListPicker1","$Type":"ListPicker","$Version":"9","Text":"Conectar Bluetooth","Uuid":"-2113836914"},{"$Name":"BluetoothClient1","$Type":"BluetoothClient","$Version":"8","Uuid":"1735224888"}]}}
|#